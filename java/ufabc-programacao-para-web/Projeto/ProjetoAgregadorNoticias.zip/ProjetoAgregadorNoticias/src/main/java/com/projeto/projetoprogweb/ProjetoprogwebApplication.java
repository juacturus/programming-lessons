package com.projeto.projetoprogweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(/*scanBasePackages = {"com.projeto.projetoprogweb.controller.ProjetoprogwebController"}*/)
public class ProjetoprogwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoprogwebApplication.class, args);
	}
}
